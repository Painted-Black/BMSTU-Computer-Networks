#pragma once

#include <string>

class SenderHandler final
{
public:
	std::string sendBytea(const std::string&, const std::string&, uint16_t);
};

