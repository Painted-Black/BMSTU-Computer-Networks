#pragma once

#include <string>

class ConnectionHandler
{
public:
	void receive(const std::string&);
};

